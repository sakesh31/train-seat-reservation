class TrainCoach {
  constructor() {
    this.totalRows = 12; // 11 rows of 7 seats + 1 row of 3 seats
    this.seatsPerRow = 7;
    this.lastRowSeats = 3;
    this.seats = this.initializeSeats();
    this.latestBooking = [];
    this.initializeUI();
  }

  initializeSeats() {
    const seats = [];
    for (let row = 0; row < this.totalRows; row++) {
      const seatsInThisRow = row === this.totalRows - 1 ? this.lastRowSeats : this.seatsPerRow;
      seats[row] = Array(seatsInThisRow).fill(false); // false means available
    }
    return seats;
  }

  initializeUI() {
    this.renderCoach();
    this.setupEventListeners();
  }

  renderCoach() {
    const coachElement = document.getElementById('coach');
    coachElement.innerHTML = '';

    this.seats.forEach((row, rowIndex) => {
      const rowElement = document.createElement('div');
      rowElement.className = 'row';

      row.forEach((isBooked, seatIndex) => {
        const seatElement = document.createElement('div');
        const seatNumber = rowIndex * this.seatsPerRow + seatIndex + 1;
        seatElement.className = `seat ${isBooked ? 'booked' : 'available'}`;
        
        // Check if this seat is part of the latest booking
        if (this.latestBooking.includes(seatNumber)) {
          seatElement.className = 'seat latest';
        }
        
        seatElement.textContent = seatNumber;
        rowElement.appendChild(seatElement);
      });

      coachElement.appendChild(rowElement);
    });
  }

  findBestSeats(numberOfSeats) {
    // Try to find seats in the same row first
    for (let row = 0; row < this.totalRows; row++) {
      const seatsInThisRow = row === this.totalRows - 1 ? this.lastRowSeats : this.seatsPerRow;
      let consecutiveSeats = 0;
      let startSeat = -1;

      for (let seat = 0; seat < seatsInThisRow; seat++) {
        if (!this.seats[row][seat]) {
          if (consecutiveSeats === 0) startSeat = seat;
          consecutiveSeats++;
          if (consecutiveSeats === numberOfSeats) {
            return { row, startSeat, consecutive: true };
          }
        } else {
          consecutiveSeats = 0;
        }
      }
    }

    // If no consecutive seats in one row, find nearest available seats
    const availableSeats = [];
    for (let row = 0; row < this.totalRows; row++) {
      const seatsInThisRow = row === this.totalRows - 1 ? this.lastRowSeats : this.seatsPerRow;
      for (let seat = 0; seat < seatsInThisRow; seat++) {
        if (!this.seats[row][seat]) {
          availableSeats.push({ row, seat });
          if (availableSeats.length === numberOfSeats) {
            return { seats: availableSeats, consecutive: false };
          }
        }
      }
    }

    return null;
  }

  bookSeats(numberOfSeats) {
    const bestSeats = this.findBestSeats(numberOfSeats);
    if (!bestSeats) {
      this.showMessage('Not enough seats available!', 'error');
      return false;
    }

    this.latestBooking = [];

    if (bestSeats.consecutive) {
      // Book consecutive seats in the same row
      for (let i = 0; i < numberOfSeats; i++) {
        this.seats[bestSeats.row][bestSeats.startSeat + i] = true;
        const seatNumber = bestSeats.row * this.seatsPerRow + (bestSeats.startSeat + i) + 1;
        this.latestBooking.push(seatNumber);
      }
    } else {
      // Book nearest available seats
      bestSeats.seats.forEach(({ row, seat }) => {
        this.seats[row][seat] = true;
        const seatNumber = row * this.seatsPerRow + seat + 1;
        this.latestBooking.push(seatNumber);
      });
    }

    this.showMessage(`Successfully booked seats: ${this.latestBooking.join(', ')}`, 'success');
    this.renderCoach();
    return true;
  }

  showMessage(text, type) {
    const messageElement = document.getElementById('message');
    messageElement.textContent = text;
    messageElement.className = `message ${type}`;
  }

  setupEventListeners() {
    const bookButton = document.getElementById('bookSeats');
    const seatsInput = document.getElementById('seats');

    bookButton.addEventListener('click', () => {
      const numberOfSeats = parseInt(seatsInput.value);
      
      if (isNaN(numberOfSeats) || numberOfSeats < 1 || numberOfSeats > 7) {
        this.showMessage('Please enter a valid number of seats (1-7)', 'error');
        return;
      }

      this.bookSeats(numberOfSeats);
    });
  }
}

// Initialize the train coach when the page loads
document.addEventListener('DOMContentLoaded', () => {
  new TrainCoach();
});